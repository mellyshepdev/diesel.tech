import { useState, useEffect } from 'react';
import Engine3D from './components/Engine3D';
import ToolPanel from './components/ToolPanel';
import ProcedurePanel from './components/ProcedurePanel';

function Header() {
  return (
    <div className="absolute top-0 left-0 right-0 z-10 flex justify-between items-center px-6 py-3 pointer-events-none">
      <div className="pointer-events-auto bg-gray-900/70 backdrop-blur-md rounded-xl px-4 py-2 border border-gray-700/50">
        <h1 className="text-xl font-black text-white tracking-tight">
          <span className="text-blue-500">VOLVO</span> D11 Diesel
        </h1>
        <p className="text-xs text-gray-400">Interactive Workshop Simulator</p>
      </div>
      <div className="pointer-events-auto bg-gray-900/70 backdrop-blur-md rounded-xl px-4 py-2 border border-gray-700/50">
        <p className="text-xs text-gray-400 font-medium">Controls</p>
        <p className="text-xs text-white font-mono">🖱️ Rotate · Scroll Zoom · Click</p>
      </div>
    </div>
  );
}

export default function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setIsLoading(false), 1200);
    return () => clearTimeout(t);
  }, []);

  if (isLoading) {
    return (
      <div className="h-screen w-screen bg-gray-950 flex items-center justify-center relative overflow-hidden">
        {/* Background grid animation */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: 'linear-gradient(rgba(59,130,246,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(59,130,246,0.3) 1px, transparent 1px)',
            backgroundSize: '50px 50px'
          }} />
        </div>
        <div className="text-center relative z-10">
          <div className="text-7xl mb-6 animate-bounce">🔧</div>
          <h1 className="text-4xl font-black text-white mb-2">
            <span className="text-blue-500">VOLVO</span> D11
          </h1>
          <p className="text-gray-400 text-lg mb-8">Engine Workshop Simulator</p>
          <div className="w-72 h-2 bg-gray-800 rounded-full overflow-hidden mx-auto">
            <div className="h-full bg-gradient-to-r from-blue-600 to-blue-400 rounded-full" 
                 style={{ width: '100%', animation: 'loadBar 1.2s ease-in-out' }} />
          </div>
          <p className="text-gray-500 text-xs mt-3">Loading engine model and tools...</p>
        </div>
        <style>{`
          @keyframes loadBar {
            0% { width: 0%; }
            100% { width: 100%; }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen bg-gray-950 flex flex-col overflow-hidden">
      <Header />

      <div className="flex-1 flex">
        {/* Left: Tool Panel */}
        <ToolPanel />

        {/* Center: 3D Engine */}
        <div className="flex-1 relative">
          <Engine3D />

          {/* Bottom instruction */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10">
            <div className="bg-gray-900/70 backdrop-blur-sm rounded-lg px-4 py-2 border border-gray-700/50 text-xs text-gray-400 text-center max-w-lg">
              Left-click + drag to rotate · Scroll to zoom · Right-click + drag to pan · Click highlighted parts to interact
            </div>
          </div>
        </div>

        {/* Right: Procedure Panel */}
        <ProcedurePanel />
      </div>
    </div>
  );
}
