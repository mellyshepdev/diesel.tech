import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment, PerspectiveCamera, Html } from '@react-three/drei';
import { useMemo } from 'react';
import EngineModel from './EngineModel';
import { useEngineStore } from '../store/engineStore';

function EngineLabels() {
  const { activeTask, valveCoverState, oilFilterState, fuelFilterState, oilDrainPlugState } = useEngineStore();

  const labels = useMemo(() => {
    const list: Array<{ key: string; position: [number, number, number]; text: string; show: boolean; color: string }> = [
      { key: 'block', position: [0, 0.4, 0.9], text: 'Engine Block', show: true, color: '#888' },
      { key: 'head', position: [0, 0.75, 0.6], text: 'Cylinder Head', show: true, color: '#aaa' },
      { key: 'valve', position: [0, 1.3, 0.6], text: 'Valve Cover', show: valveCoverState !== 'removed', color: '#ccc' },
      { key: 'injector', position: [0.6, 1.05, -0.1], text: 'Injectors', show: true, color: '#aaa' },
      { key: 'turbo', position: [0.85, 0.6, -0.6], text: 'Turbocharger', show: true, color: '#cc9933' },
      { key: 'exhaust', position: [0.5, 0.3, -0.65], text: 'Exhaust', show: true, color: '#884422' },
      { key: 'intake', position: [0.5, 0.6, 0.65], text: 'Intake', show: true, color: '#2255aa' },
      { key: 'oilfilter', position: [-0.9, -0.5, 0.5], text: 'Oil Filter', show: oilFilterState === 'installed', color: '#228833' },
      { key: 'fuelfilter', position: [0.9, 0.0, 0.5], text: 'Fuel Filter', show: fuelFilterState !== 'removed', color: '#ddaa22' },
      { key: 'drain', position: [0.15, -1.05, 0.35], text: 'Drain Plug', show: oilDrainPlugState !== 'removed', color: '#666' },
      { key: 'oilfill', position: [-0.15, 0.9, 0.55], text: 'Oil Fill', show: true, color: '#ff6600' },
      { key: 'alternator', position: [0.85, 0.2, 0.5], text: 'Alternator', show: true, color: '#555' },
      { key: 'flywheel', position: [0, 0, -0.75], text: 'Flywheel', show: true, color: '#444' },
      { key: 'starter', position: [-0.8, -0.3, -0.4], text: 'Starter', show: true, color: '#555' },
    ];
    return list.filter((l) => l.show);
  }, [activeTask, valveCoverState, oilFilterState, fuelFilterState, oilDrainPlugState]);

  return (
    <>
      {labels.map((label) => (
        <Html key={label.key} position={label.position} center distanceFactor={15} transform>
          <div className="pointer-events-none select-none">
            <div className="text-[10px] font-mono font-bold whitespace-nowrap px-1.5 py-0.5 rounded-sm" 
                 style={{ color: label.color, textShadow: '0 0 4px rgba(0,0,0,0.9), 0 0 8px rgba(0,0,0,0.7)' }}>
              {label.text}
            </div>
          </div>
        </Html>
      ))}
    </>
  );
}

export default function Engine3D() {
  return (
    <Canvas
      shadows
      camera={{ position: [3, 2, 3], fov: 50 }}
      style={{ cursor: 'default' }}
    >
      <PerspectiveCamera makeDefault position={[3, 2, 3]} />
      <OrbitControls
        enablePan
        enableZoom
        enableRotate
        minDistance={1.5}
        maxDistance={8}
        minPolarAngle={0.2}
        maxPolarAngle={Math.PI / 1.5}
        target={[0, 0.3, 0]}
        enableDamping
        dampingFactor={0.08}
      />

      <ambientLight intensity={0.4} />
      <directionalLight
        position={[5, 8, 5]}
        intensity={1.2}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />
      <directionalLight position={[-3, 4, -3]} intensity={0.5} color="#8888ff" />
      <pointLight position={[2, 3, 2]} intensity={0.3} color="#ffffff" />

      <Environment preset="warehouse" />

      {/* Floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.5, 0]} receiveShadow>
        <planeGeometry args={[20, 20]} />
        <meshStandardMaterial color="#2a2a2a" metalness={0.1} roughness={0.9} />
      </mesh>

      <gridHelper args={[10, 20, '#444', '#333']} position={[0, -1.49, 0]} />

      <EngineModel />
      <EngineLabels />
    </Canvas>
  );
}
