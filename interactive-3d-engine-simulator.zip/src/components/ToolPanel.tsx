import { Tool, useEngineStore } from '../store/engineStore';

const toolInfo: Record<Tool, { name: string; icon: string; desc: string }> = {
  ratchet: { name: 'Ratchet Wrench', icon: '🔧', desc: 'Reversible ratchet drive' },
  socket8: { name: '8mm Socket', icon: '⚙️', desc: 'Valve cover bolts' },
  socket10: { name: '10mm Socket', icon: '⚙️', desc: 'Various fasteners' },
  socket13: { name: '13mm Socket', icon: '⚙️', desc: 'Oil drain plug' },
  socket15: { name: '15mm Socket', icon: '⚙️', desc: 'Alternator bolts' },
  socket21: { name: '21mm Socket', icon: '⚙️', desc: 'Fuel filter housing' },
  extension: { name: 'Extension Bar', icon: '📏', desc: 'Reach deep bolts' },
  drainPan: { name: 'Drain Pan', icon: '🛢️', desc: 'Catch draining oil' },
  filterWrench: { name: 'Filter Wrench', icon: '🔩', desc: 'Oil filter removal' },
  funnel: { name: 'Funnel', icon: '🫗', desc: 'Pour new oil' },
  screwdriver: { name: 'Screwdriver', icon: '🪛', desc: 'Phillips/Flat blade' },
  towel: { name: 'Towel/Rags', icon: '🧽', desc: 'Clean surfaces' },
};

export default function ToolPanel() {
  const { selectedTool, selectTool, setRatchetAttachment, activeTask, procedureSteps, currentStepIndex } = useEngineStore();
  const currentStep = procedureSteps[currentStepIndex];
  const needsAttachment = activeTask === 'valveCover' && (currentStep?.action === 'attach_extension' || currentStep?.action === 'attach_socket8');

  const handleToolClick = (tool: Tool) => {
    if (needsAttachment) {
      // Check if this is the right attachment
      if (tool === currentStep.requiredTool) {
        setRatchetAttachment(tool);
      }
    } else {
      selectTool(tool);
    }
  };

  return (
    <div className="w-72 bg-gray-900/95 backdrop-blur-sm border-r border-gray-700 flex flex-col h-full">
      <div className="p-4 border-b border-gray-700">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <span className="text-2xl">🧰</span> Toolbox
        </h2>
        {needsAttachment && (
          <p className="text-xs text-yellow-400 mt-1">
            Click the attachment to add to ratchet
          </p>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {Object.entries(toolInfo).map(([key, info]) => {
          const tool = key as Tool;
          const isSelected = selectedTool === tool;
          const isRequired = currentStep?.requiredTool === tool;

          return (
            <button
              key={key}
              onClick={() => handleToolClick(tool)}
              className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all duration-200 text-left ${
                isSelected
                  ? 'bg-blue-600/30 border-2 border-blue-500 shadow-lg shadow-blue-500/20'
                  : isRequired
                  ? 'bg-yellow-600/20 border-2 border-yellow-500 animate-pulse'
                  : 'bg-gray-800/50 border border-gray-700 hover:bg-gray-700/50 hover:border-gray-600'
              }`}
            >
              <span className="text-2xl">{info.icon}</span>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-white truncate">{info.name}</div>
                <div className="text-xs text-gray-400">{info.desc}</div>
              </div>
              {isRequired && !isSelected && (
                <span className="text-xs bg-yellow-500 text-black font-bold px-2 py-0.5 rounded-full">
                  NEED
                </span>
              )}
              {isSelected && (
                <span className="text-xs bg-blue-500 text-white font-bold px-2 py-0.5 rounded-full">
                  ✓
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
