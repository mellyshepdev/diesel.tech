import { useEngineStore, ActiveTask } from '../store/engineStore';

const taskInfo: Record<Exclude<ActiveTask, 'none'>, { title: string; icon: string; desc: string }> = {
  valveCover: { title: 'Valve Cover Removal', icon: '🔧', desc: 'Remove valve cover bolts and lift off cover' },
  oilChange: { title: 'Oil Change', icon: '🛢️', desc: 'Drain oil, replace filter, refill' },
  oilFilter: { title: 'Oil Filter Change', icon: '🔄', desc: 'Replace oil filter with proper technique' },
  fuelFilter: { title: 'Fuel Filter Change', icon: '⛽', desc: 'Replace diesel fuel filter' },
};

export default function ProcedurePanel() {
  const {
    activeTask, setActiveTask, procedureSteps,
    message, messageType, resetEngine, positionDrainPan,
    valveCoverState, oilLevel, oilFilterState, fuelFilterState,
    drainPanPositioned
  } = useEngineStore();

  return (
    <div className="w-80 bg-gray-900/95 backdrop-blur-sm border-l border-gray-700 flex flex-col h-full">
      {/* Message Banner */}
      <div className={`p-3 border-b border-gray-700 ${
        messageType === 'success' ? 'bg-green-900/40 border-green-700' :
        messageType === 'error' ? 'bg-red-900/40 border-red-700' :
        messageType === 'warning' ? 'bg-yellow-900/40 border-yellow-700' :
        'bg-blue-900/30 border-blue-700'
      }`}>
        <p className="text-sm text-white">{message}</p>
      </div>

      {/* Task Selection */}
      <div className="p-4 border-b border-gray-700">
        <h2 className="text-lg font-bold text-white mb-3">📋 Maintenance Tasks</h2>
        <div className="space-y-2">
          {(Object.entries(taskInfo) as [Exclude<ActiveTask, 'none'>, typeof taskInfo[Exclude<ActiveTask, 'none'>]][]).map(([key, info]) => (
            <button
              key={key}
              onClick={() => setActiveTask(key)}
              disabled={activeTask === key}
              className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left ${
                activeTask === key
                  ? 'bg-blue-600/30 border border-blue-500'
                  : 'bg-gray-800/50 border border-gray-700 hover:bg-gray-700/50 hover:border-gray-600'
              }`}
            >
              <span className="text-xl">{info.icon}</span>
              <div className="flex-1">
                <div className="text-sm font-semibold text-white">{info.title}</div>
                <div className="text-xs text-gray-400">{info.desc}</div>
              </div>
              {activeTask === key && (
                <span className="text-xs bg-blue-500 text-white px-2 py-0.5 rounded-full">ACTIVE</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Engine Status */}
      <div className="p-4 border-b border-gray-700">
        <h3 className="text-sm font-bold text-gray-400 mb-2 uppercase tracking-wider">Engine Status</h3>
        <div className="space-y-1.5 text-sm">
          <StatusRow label="Valve Cover" status={valveCoverState} />
          <StatusRow label="Oil Level" status={oilLevel} />
          <StatusRow label="Oil Filter" status={oilFilterState} />
          <StatusRow label="Fuel Filter" status={fuelFilterState} />
          <StatusRow label="Drain Pan" status={drainPanPositioned ? 'positioned' as const : 'not positioned' as const} />
        </div>
      </div>

      {/* Procedure Steps */}
      {activeTask !== 'none' && procedureSteps.length > 0 && (
        <div className="flex-1 overflow-y-auto p-4">
          <h3 className="text-sm font-bold text-gray-400 mb-3 uppercase tracking-wider">
            Procedure: {taskInfo[activeTask]?.title}
          </h3>
          <div className="space-y-2">
            {procedureSteps.map((step) => (
              <div
                key={step.id}
                className={`flex gap-3 p-2.5 rounded-lg transition-all ${
                  step.completed
                    ? 'bg-green-900/30 border border-green-700/50'
                    : step.current
                    ? 'bg-yellow-900/30 border border-yellow-600 shadow-lg shadow-yellow-500/10'
                    : 'bg-gray-800/30 border border-gray-700/50'
                }`}
              >
                <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  step.completed ? 'bg-green-600 text-white' :
                  step.current ? 'bg-yellow-500 text-black animate-pulse' :
                  'bg-gray-600 text-gray-300'
                }`}>
                  {step.completed ? '✓' : step.id}
                </div>
                <div>
                  <p className={`text-sm ${
                    step.completed ? 'text-green-300 line-through' :
                    step.current ? 'text-white font-medium' :
                    'text-gray-400'
                  }`}>
                    {step.description}
                  </p>
                  {step.requiredTool && step.current && (
                    <span className="text-xs text-yellow-400 mt-0.5 inline-block">
                      Required: {step.requiredTool === 'ratchet' ? 'Ratchet Wrench' :
                        step.requiredTool === 'socket8' ? '8mm Socket' :
                        step.requiredTool === 'socket13' ? '13mm Socket' :
                        step.requiredTool === 'socket21' ? '21mm Socket' :
                        step.requiredTool === 'extension' ? 'Extension Bar' :
                        step.requiredTool === 'drainPan' ? 'Drain Pan' :
                        step.requiredTool === 'filterWrench' ? 'Filter Wrench' :
                        step.requiredTool === 'funnel' ? 'Funnel' : 'Towel'}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Drain Pan Button */}
          {(activeTask === 'oilChange' || activeTask === 'oilFilter') && (
            <button
              onClick={positionDrainPan}
              className={`mt-3 w-full py-2 rounded-lg font-semibold text-sm transition-all ${
                drainPanPositioned
                  ? 'bg-green-600/30 text-green-300 border border-green-600'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              {drainPanPositioned ? '✓ Drain Pan Positioned' : '🛢️ Position Drain Pan'}
            </button>
          )}
        </div>
      )}

      {/* Reset Button */}
      <div className="p-4 border-t border-gray-700">
        <button
          onClick={resetEngine}
          className="w-full py-2.5 bg-red-600/20 text-red-400 border border-red-600/50 rounded-lg font-semibold text-sm hover:bg-red-600/30 transition-all"
        >
          🔄 Reset Engine
        </button>
      </div>
    </div>
  );
}

function StatusRow({ label, status }: { label: string; status: string }) {
  const color = status === 'installed' || status === 'full' || status === 'positioned'
    ? 'text-green-400'
    : status === 'removed' || status === 'drained' || status === 'loose'
    ? 'text-red-400'
    : status === 'installed_new'
    ? 'text-green-300'
    : status === 'draining'
    ? 'text-yellow-400'
    : 'text-gray-400';

  return (
    <div className="flex justify-between items-center">
      <span className="text-gray-400">{label}</span>
      <span className={`text-xs font-medium uppercase ${color}`}>{status}</span>
    </div>
  );
}
