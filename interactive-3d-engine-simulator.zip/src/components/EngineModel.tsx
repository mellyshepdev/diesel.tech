import { useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { useEngineStore, BoltState } from '../store/engineStore';

// Cursor management
const setCursor = (type: 'pointer' | 'default') => {
  const canvas = document.querySelector('canvas');
  if (canvas) canvas.style.cursor = type === 'pointer' ? 'pointer' : 'default';
};

const matSteel = { color: '#5a5a5a', metalness: 0.8, roughness: 0.3 };
const matCastIron = { color: '#3a3a3a', metalness: 0.6, roughness: 0.5 };
const matAluminum = { color: '#8a8a8a', metalness: 0.7, roughness: 0.3 };
const matCopper = { color: '#b87333', metalness: 0.8, roughness: 0.2 };
const matChrome = { color: '#c0c0c0', metalness: 0.95, roughness: 0.05 };
const matRed = { color: '#cc2222', metalness: 0.5, roughness: 0.4 };
const matBlue = { color: '#2255aa', metalness: 0.5, roughness: 0.4 };
const matYellow = { color: '#ddaa22', metalness: 0.5, roughness: 0.4 };
const matGreen = { color: '#228833', metalness: 0.5, roughness: 0.4 };
const matOrange = { color: '#ff6600', metalness: 0.5, roughness: 0.4 };

function Bolt({ position, state, boltId }: {
  position: [number, number, number];
  state: BoltState;
  boltId: string;
}) {
  const ref = useRef<THREE.Mesh>(null);
  const color = state === 'tight' ? '#888' : state === 'loose' ? '#cc4444' : '#44aa44';
  const { clickBolt, activeTask, procedureSteps, currentStepIndex } = useEngineStore();

  useFrame(() => {
    if (ref.current && state === 'loose') {
      ref.current.rotation.y += 0.02;
    }
  });

  const isInteractive = activeTask === 'valveCover' &&
    (procedureSteps[currentStepIndex]?.action === 'loosen_bolts' || procedureSteps[currentStepIndex]?.action === 'unscrew_bolts');

  return (
    <group
      position={position}
      {...(isInteractive ? { 
        onClick: (e) => { e.stopPropagation(); clickBolt(boltId); },
        onPointerOver: () => setCursor('pointer'),
        onPointerOut: () => setCursor('default')
      } : {})}
    >
      <mesh ref={ref} castShadow>
        <cylinderGeometry args={[0.04, 0.04, 0.08, 8]} />
        <meshStandardMaterial color={color} metalness={0.8} roughness={0.3} />
      </mesh>
      <mesh position={[0, 0.05, 0]} castShadow>
        <cylinderGeometry args={[0.05, 0.05, 0.02, 6]} />
        <meshStandardMaterial color={color} metalness={0.8} roughness={0.3} />
      </mesh>
    </group>
  );
}

export default function EngineModel() {
  const {
    valveCoverBolts, valveCoverState,
    oilDrainPlugState, oilLevel, drainPanPositioned,
    oilFilterState, fuelFilterState, fuelFilterBoltState,
    activeTask, currentStepIndex, procedureSteps, ratchetAttachments,
    clickPart, selectTool
  } = useEngineStore();

  const valveCoverRef = useRef<THREE.Group>(null);

  useFrame(() => {
    if (valveCoverRef.current) {
      const targetY = valveCoverState === 'removed' ? 3 : 0;
      valveCoverRef.current.position.y += (targetY - valveCoverRef.current.position.y) * 0.05;
    }
  });

  const currentStep = procedureSteps[currentStepIndex];
  const needsRatchetAssembly = activeTask === 'valveCover' && (currentStep?.action === 'attach_extension' || currentStep?.action === 'attach_socket8');

  return (
    <group position={[0, -0.5, 0]}>
      {/* ENGINE BLOCK */}
      <mesh position={[0, 0, 0]} castShadow>
        <boxGeometry args={[1.2, 1.4, 0.9]} />
        <meshStandardMaterial {...matCastIron} />
      </mesh>

      {/* Block fins */}
      {[0.2, 0.5, 0.8, 1.1].map((x, i) => (
        <mesh key={`fin-${i}`} position={[x, 0, 0.46]} castShadow>
          <boxGeometry args={[0.02, 1.0, 0.06]} />
          <meshStandardMaterial {...matCastIron} />
        </mesh>
      ))}

      {/* CYLINDER HEAD */}
      <mesh position={[0, 0.75, 0]} castShadow>
        <boxGeometry args={[1.15, 0.15, 0.85]} />
        <meshStandardMaterial {...matAluminum} />
      </mesh>

      {/* Cylinder head fins */}
      {[-0.8, -0.5, -0.2, 0.1, 0.4, 0.7].map((x, i) => (
        <mesh key={`hf-${i}`} position={[x, 0.85, 0.43]} castShadow>
          <boxGeometry args={[0.08, 0.3, 0.03]} />
          <meshStandardMaterial {...matAluminum} />
        </mesh>
      ))}

      {/* INJECTOR RAIL */}
      <mesh position={[0, 0.92, -0.1]} castShadow>
        <boxGeometry args={[1.1, 0.06, 0.08]} />
        <meshStandardMaterial {...matSteel} />
      </mesh>

      {/* Injectors */}
      {[-0.8, -0.4, 0.0, 0.4, 0.8].map((x, i) => (
        <mesh key={`inj-${i}`} position={[x, 0.98, -0.1]} castShadow>
          <cylinderGeometry args={[0.03, 0.03, 0.1, 8]} />
          <meshStandardMaterial {...matChrome} />
        </mesh>
      ))}

      {/* Injector lines */}
      {[-0.8, -0.4, 0.0, 0.4, 0.8].map((x, i) => (
        <mesh key={`il-${i}`} position={[x, 1.05, -0.1]} castShadow>
          <cylinderGeometry args={[0.01, 0.01, 0.08, 6]} />
          <meshStandardMaterial {...matCopper} />
        </mesh>
      ))}

      {/* VALVE COVER (animated) */}
      <group
        ref={valveCoverRef}
        onClick={() => clickPart('valveCover')}
      >
        {valveCoverState !== 'removed' && (
          <>
            <mesh position={[0, 1.12, 0]} castShadow>
              <boxGeometry args={[1.1, 0.18, 0.8]} />
              <meshStandardMaterial {...matAluminum} transparent opacity={0.9} />
            </mesh>
            <mesh position={[0, 1.22, 0]} castShadow>
              <boxGeometry args={[1.05, 0.04, 0.75]} />
              <meshStandardMaterial {...matAluminum} />
            </mesh>
            <mesh position={[-0.5, 1.28, 0]} castShadow>
              <cylinderGeometry args={[0.06, 0.06, 0.05, 12]} />
              <meshStandardMaterial {...matRed} />
            </mesh>
          </>
        )}
      </group>

      {/* VALVE COVER BOLTS */}
      {valveCoverBolts.map((bolt) => (
        <Bolt key={bolt.id} position={bolt.position} state={bolt.state} boltId={bolt.id} />
      ))}

      {/* OIL PAN */}
      <mesh position={[0, -0.85, 0]} castShadow>
        <boxGeometry args={[1.0, 0.25, 0.7]} />
        <meshStandardMaterial {...matCastIron} />
      </mesh>

      {[-0.3, 0, 0.3].map((x, i) => (
        <mesh key={`pr-${i}`} position={[x, -0.72, 0.36]} castShadow>
          <boxGeometry args={[0.02, 0.15, 0.04]} />
          <meshStandardMaterial {...matCastIron} />
        </mesh>
      ))}

      {/* OIL DRAIN PLUG */}
      {oilDrainPlugState !== 'removed' && (
        <group
          position={[0, -0.98, 0.3]}
          onClick={(e) => { e.stopPropagation(); clickPart('drainPlug'); }}
          onPointerOver={() => setCursor('pointer')}
          onPointerOut={() => setCursor('default')}
        >
          <mesh castShadow>
            <cylinderGeometry args={[0.05, 0.05, 0.08, 8]} />
            <meshStandardMaterial color="#666" metalness={0.8} roughness={0.3} />
          </mesh>
          <mesh position={[0, 0.05, 0]} castShadow>
            <cylinderGeometry args={[0.06, 0.06, 0.015, 6]} />
            <meshStandardMaterial color="#888" metalness={0.8} roughness={0.3} />
          </mesh>
        </group>
      )}

      {/* Oil drips */}
      {oilLevel === 'draining' && oilDrainPlugState === 'removed' && (
        <mesh position={[0, -1.15, 0.3]}>
          <sphereGeometry args={[0.02, 8, 8]} />
          <meshStandardMaterial color="#332200" transparent opacity={0.7} />
        </mesh>
      )}

      {/* OIL FILTER */}
      {(oilFilterState === 'installed') && (
        <group
          onClick={() => clickPart('oilFilter')}
          onPointerOver={() => setCursor('pointer')}
          onPointerOut={() => setCursor('default')}
        >
          <mesh position={[-0.75, -0.5, 0.5]} castShadow>
            <cylinderGeometry args={[0.08, 0.08, 0.22, 12]} />
            <meshStandardMaterial {...matGreen} />
          </mesh>
        </group>
      )}

      {oilFilterState === 'removed' && (
        <mesh
          position={[-0.75, -0.5, 0.48]}
          onClick={() => clickPart('filterMount')}
          onPointerOver={() => setCursor('pointer')}
          onPointerOut={() => setCursor('default')}
          castShadow
        >
          <cylinderGeometry args={[0.06, 0.06, 0.03, 12]} />
          <meshStandardMaterial {...matSteel} />
        </mesh>
      )}

      {oilFilterState === 'installed_new' && (
        <mesh position={[-0.75, -0.5, 0.5]} castShadow>
          <cylinderGeometry args={[0.08, 0.08, 0.22, 12]} />
          <meshStandardMaterial color="#22aa44" metalness={0.5} roughness={0.4} />
        </mesh>
      )}

      {/* FUEL FILTER */}
      {fuelFilterState !== 'removed' && (
        <group 
          onClick={() => clickPart('fuelFilter')}
          onPointerOver={() => setCursor('pointer')}
          onPointerOut={() => setCursor('default')}
        >
          <mesh position={[0.75, 0.0, 0.5]} castShadow>
            <cylinderGeometry args={[0.07, 0.07, 0.18, 12]} />
            <meshStandardMaterial {...matYellow} />
          </mesh>
        </group>
      )}

      {fuelFilterState !== 'removed' && fuelFilterBoltState !== 'loose' && (
        <mesh
          position={[0.75, 0.1, 0.55]}
          onClick={() => clickPart('fuelFilterBolt')}
          onPointerOver={() => setCursor('pointer')}
          onPointerOut={() => setCursor('default')}
          castShadow
        >
          <cylinderGeometry args={[0.04, 0.04, 0.06, 8]} />
          <meshStandardMaterial color="#888" metalness={0.8} roughness={0.3} />
        </mesh>
      )}

      {(fuelFilterState === 'removed' || fuelFilterState === 'installed_new') && (
        <mesh
          position={[0.75, 0.0, 0.48]}
          onClick={() => clickPart('fuelMount')}
          onPointerOver={() => setCursor('pointer')}
          onPointerOut={() => setCursor('default')}
          castShadow
        >
          <cylinderGeometry args={[0.05, 0.05, 0.03, 12]} />
          <meshStandardMaterial {...matSteel} />
        </mesh>
      )}

      {fuelFilterState === 'installed_new' && (
        <mesh position={[0.75, 0.0, 0.5]} castShadow>
          <cylinderGeometry args={[0.07, 0.07, 0.18, 12]} />
          <meshStandardMaterial color="#ddcc22" metalness={0.5} roughness={0.4} />
        </mesh>
      )}

      {/* TURBOCHARGER */}
      <mesh position={[0.6, 0.6, -0.45]} castShadow>
        <cylinderGeometry args={[0.2, 0.2, 0.15, 16]} />
        <meshStandardMaterial {...matSteel} />
      </mesh>
      <mesh position={[0.6, 0.6, -0.55]} castShadow>
        <cylinderGeometry args={[0.15, 0.18, 0.05, 16]} />
        <meshStandardMaterial {...matChrome} />
      </mesh>
      <mesh position={[0.6, 0.6, -0.7]} castShadow>
        <cylinderGeometry args={[0.04, 0.04, 0.2, 8]} />
        <meshStandardMaterial {...matCopper} />
      </mesh>

      {/* EXHAUST MANIFOLD */}
      <mesh position={[0, 0.3, -0.5]} castShadow>
        <boxGeometry args={[0.8, 0.2, 0.15]} />
        <meshStandardMaterial color="#884422" metalness={0.7} roughness={0.4} />
      </mesh>
      {[-0.3, 0, 0.3].map((x, i) => (
        <mesh key={`exh-${i}`} position={[x, 0.4, -0.58]} castShadow>
          <cylinderGeometry args={[0.04, 0.04, 0.15, 8]} />
          <meshStandardMaterial color="#884422" metalness={0.7} roughness={0.4} />
        </mesh>
      ))}

      {/* INTAKE MANIFOLD */}
      <mesh position={[0, 0.55, 0.48]} castShadow>
        <boxGeometry args={[0.7, 0.15, 0.2]} />
        <meshStandardMaterial {...matAluminum} />
      </mesh>
      <mesh position={[-0.35, 0.62, 0.58]} castShadow>
        <cylinderGeometry args={[0.06, 0.06, 0.25, 8]} />
        <meshStandardMaterial {...matBlue} />
      </mesh>

      {/* FLYWHEEL */}
      <mesh position={[0, 0, -0.55]} castShadow>
        <cylinderGeometry args={[0.35, 0.35, 0.15, 24]} />
        <meshStandardMaterial {...matCastIron} />
      </mesh>

      {/* ALTERNATOR */}
      <mesh position={[0.7, 0.2, 0.45]} castShadow>
        <cylinderGeometry args={[0.12, 0.12, 0.1, 16]} />
        <meshStandardMaterial {...matCastIron} />
      </mesh>

      {/* STARTER */}
      <mesh position={[-0.6, -0.3, -0.4]} castShadow>
        <cylinderGeometry args={[0.1, 0.1, 0.25, 12]} />
        <meshStandardMaterial {...matCastIron} />
      </mesh>

      {/* OIL FILL */}
      <mesh
        position={[-0.3, 0.85, 0.48]}
        onClick={() => clickPart('oilFill')}
        castShadow
      >
        <cylinderGeometry args={[0.07, 0.07, 0.06, 12]} />
        <meshStandardMaterial {...matOrange} />
      </mesh>

      {/* VOLVO BADGE */}
      <mesh position={[0, 0.3, 0.46]}>
        <boxGeometry args={[0.5, 0.12, 0.01]} />
        <meshStandardMaterial color="#2255cc" metalness={0.3} roughness={0.6} />
      </mesh>

      {/* DRAIN PAN */}
      {drainPanPositioned && (
        <group position={[0, -1.3, 0]}>
          <mesh castShadow>
            <boxGeometry args={[1.2, 0.08, 0.6]} />
            <meshStandardMaterial color="#444466" metalness={0.6} roughness={0.4} />
          </mesh>
          <mesh position={[0, 0.06, 0.3]}>
            <boxGeometry args={[1.2, 0.12, 0.02]} />
            <meshStandardMaterial color="#444466" metalness={0.6} roughness={0.4} />
          </mesh>
          <mesh position={[0, 0.06, -0.3]}>
            <boxGeometry args={[1.2, 0.12, 0.02]} />
            <meshStandardMaterial color="#444466" metalness={0.6} roughness={0.4} />
          </mesh>
          <mesh position={[0.59, 0.06, 0]}>
            <boxGeometry args={[0.02, 0.12, 0.6]} />
            <meshStandardMaterial color="#444466" metalness={0.6} roughness={0.4} />
          </mesh>
          <mesh position={[-0.59, 0.06, 0]}>
            <boxGeometry args={[0.02, 0.12, 0.6]} />
            <meshStandardMaterial color="#444466" metalness={0.6} roughness={0.4} />
          </mesh>
          {(oilLevel === 'drained' || oilLevel === 'draining') && (
            <mesh position={[0, -0.01, 0]}>
              <boxGeometry args={[1.0, 0.03, 0.4]} />
              <meshStandardMaterial color="#221100" metalness={0.2} roughness={0.8} transparent opacity={0.8} />
            </mesh>
          )}
        </group>
      )}

      {/* INTERACTIVE HIGHLIGHTS */}
      {activeTask !== 'none' && (
        <>
          {activeTask === 'oilChange' && currentStep &&
            ['remove_drain_plug', 'wait_drain', 'reinstall_drain_plug'].includes(currentStep.action) &&
            oilDrainPlugState !== 'removed' && (
              <mesh position={[0, -0.98, 0.3]}>
                <sphereGeometry args={[0.1, 12, 12]} />
                <meshStandardMaterial color="#ffaa00" transparent opacity={0.2} />
              </mesh>
            )
          }

          {activeTask === 'oilChange' && currentStep?.action === 'add_oil' && (
            <mesh position={[-0.3, 0.85, 0.48]}>
              <sphereGeometry args={[0.12, 12, 12]} />
              <meshStandardMaterial color="#ffaa00" transparent opacity={0.2} />
            </mesh>
          )}

          {activeTask === 'oilFilter' && currentStep?.action === 'remove_filter' && (
            <mesh position={[-0.75, -0.5, 0.5]}>
              <sphereGeometry args={[0.12, 12, 12]} />
              <meshStandardMaterial color="#ffaa00" transparent opacity={0.2} />
            </mesh>
          )}
          {activeTask === 'oilFilter' && (currentStep?.action === 'clean_filter_area' || currentStep?.action === 'install_new_filter') && (
            <mesh position={[-0.75, -0.5, 0.48]}>
              <sphereGeometry args={[0.1, 12, 12]} />
              <meshStandardMaterial color="#ffaa00" transparent opacity={0.2} />
            </mesh>
          )}

          {activeTask === 'fuelFilter' && currentStep?.action === 'loosen_fuel_bolt' && (
            <mesh position={[0.75, 0.1, 0.55]}>
              <sphereGeometry args={[0.08, 12, 12]} />
              <meshStandardMaterial color="#ffaa00" transparent opacity={0.2} />
            </mesh>
          )}
          {activeTask === 'fuelFilter' && currentStep?.action === 'remove_fuel_filter' && (
            <mesh position={[0.75, 0.0, 0.5]}>
              <sphereGeometry args={[0.1, 12, 12]} />
              <meshStandardMaterial color="#ffaa00" transparent opacity={0.2} />
            </mesh>
          )}
          {activeTask === 'fuelFilter' && (currentStep?.action === 'clean_fuel_area' || currentStep?.action === 'install_new_fuel_filter') && (
            <mesh position={[0.75, 0.0, 0.48]}>
              <sphereGeometry args={[0.1, 12, 12]} />
              <meshStandardMaterial color="#ffaa00" transparent opacity={0.2} />
            </mesh>
          )}

          {activeTask === 'valveCover' && (currentStep?.action === 'loosen_bolts' || currentStep?.action === 'unscrew_bolts') && valveCoverBolts.map((bolt) => {
            const canClick = (currentStep.action === 'loosen_bolts' && bolt.state === 'tight') ||
                            (currentStep.action === 'unscrew_bolts' && bolt.state === 'loose');
            return canClick ? (
              <mesh key={`gl-${bolt.id}`} position={bolt.position}>
                <sphereGeometry args={[0.08, 12, 12]} />
                <meshStandardMaterial color="#ffaa00" transparent opacity={0.15} />
              </mesh>
            ) : null;
          })}

          {activeTask === 'valveCover' && currentStep?.action === 'remove_cover' && (
            <mesh position={[0, 1.12, 0]}>
              <boxGeometry args={[1.2, 0.25, 0.9]} />
              <meshStandardMaterial color="#ffaa00" transparent opacity={0.1} />
            </mesh>
          )}
        </>
      )}

      {/* RATCHET ASSEMBLY PREVIEW */}
      {needsRatchetAssembly && (
        <group position={[1.5, 1.8, 1.0]}>
          <mesh onClick={() => selectTool('ratchet')}>
            <boxGeometry args={[0.25, 0.18, 0.12]} />
            <meshStandardMaterial color="#333" metalness={0.9} roughness={0.2} />
          </mesh>
          {ratchetAttachments.includes('extension') && (
            <mesh position={[0.2, 0, 0]}>
              <boxGeometry args={[0.2, 0.04, 0.04]} />
              <meshStandardMaterial color="#555" metalness={0.8} roughness={0.3} />
            </mesh>
          )}
          {ratchetAttachments.includes('socket8') && (
            <mesh position={ratchetAttachments.includes('extension') ? [0.35, 0, 0] : [0.3, 0, 0]}>
              <cylinderGeometry args={[0.05, 0.05, 0.1, 12]} />
              <meshStandardMaterial color="#888" metalness={0.8} roughness={0.3} />
            </mesh>
          )}
        </group>
      )}
    </group>
  );
}
