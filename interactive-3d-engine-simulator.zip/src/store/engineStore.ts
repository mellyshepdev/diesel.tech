import { create } from 'zustand';

export type Tool = 
  | 'ratchet' 
  | 'socket8' 
  | 'socket10' 
  | 'socket13' 
  | 'socket15'
  | 'socket21'
  | 'extension' 
  | 'drainPan' 
  | 'filterWrench' 
  | 'funnel'
  | 'screwdriver'
  | 'towel';

export type BoltState = 'tight' | 'loosening' | 'loose' | 'removed';
export type PartState = 'installed' | 'ready_remove' | 'removed' | 'installed_new';
export type OilLevel = 'full' | 'draining' | 'drained' | 'refilling' | 'refilled';

export interface ValveCoverBolt {
  id: string;
  position: [number, number, number];
  state: BoltState;
  socketSize: string;
}

export interface ProcedureStep {
  id: number;
  description: string;
  requiredTool: Tool | null;
  requiredAttachments?: Tool[];
  action: string;
  completed: boolean;
  current: boolean;
}

export type ActiveTask = 'none' | 'valveCover' | 'oilChange' | 'oilFilter' | 'fuelFilter';

interface EngineStore {
  isExploded: boolean;
  selectedTool: Tool | null;
  ratchetAttachments: Tool[];
  hoveredPart: string | null;
  activeTask: ActiveTask;
  procedureSteps: ProcedureStep[];
  currentStepIndex: number;
  valveCoverBolts: ValveCoverBolt[];
  valveCoverState: PartState;
  oilDrainPlugState: BoltState;
  oilLevel: OilLevel;
  drainPanPositioned: boolean;
  oilFilterState: PartState;
  fuelFilterState: PartState;
  fuelFilterBoltState: BoltState;
  message: string;
  messageType: 'info' | 'success' | 'error' | 'warning';
  selectTool: (tool: Tool | null) => void;
  setRatchetAttachment: (attachment: Tool) => void;
  clearRatchetAttachments: () => void;
  setActiveTask: (task: ActiveTask) => void;
  advanceStep: () => void;
  clickBolt: (boltId: string) => void;
  clickPart: (partName: string) => void;
  positionDrainPan: () => void;
  showMessage: (message: string, type: 'info' | 'success' | 'error' | 'warning') => void;
  resetEngine: () => void;
}

const initialValveCoverBolts: ValveCoverBolt[] = [
  { id: 'vc1', position: [-0.85, 1.25, 0.45], state: 'tight', socketSize: '8' },
  { id: 'vc2', position: [-0.45, 1.25, 0.45], state: 'tight', socketSize: '8' },
  { id: 'vc3', position: [0.0, 1.25, 0.45], state: 'tight', socketSize: '8' },
  { id: 'vc4', position: [0.45, 1.25, 0.45], state: 'tight', socketSize: '8' },
  { id: 'vc5', position: [0.85, 1.25, 0.45], state: 'tight', socketSize: '8' },
  { id: 'vc6', position: [-0.85, 1.25, -0.45], state: 'tight', socketSize: '8' },
  { id: 'vc7', position: [-0.45, 1.25, -0.45], state: 'tight', socketSize: '8' },
  { id: 'vc8', position: [0.0, 1.25, -0.45], state: 'tight', socketSize: '8' },
  { id: 'vc9', position: [0.45, 1.25, -0.45], state: 'tight', socketSize: '8' },
];

const makeSteps = (steps: Omit<ProcedureStep, 'completed' | 'current'>[]): ProcedureStep[] =>
  steps.map((s, i) => ({ ...s, completed: false, current: i === 0 }));

const valCoverSteps = makeSteps([
  { id: 1, description: 'Select the Ratchet Wrench from the toolbox', requiredTool: 'ratchet', action: 'select_ratchet' },
  { id: 2, description: 'Attach the Extension bar to the ratchet', requiredTool: 'extension', action: 'attach_extension' },
  { id: 3, description: 'Attach the 8mm Socket to the extension', requiredTool: 'socket8', action: 'attach_socket8' },
  { id: 4, description: 'Click each valve cover bolt (9 total) to loosen them with the ratchet', requiredTool: null, action: 'loosen_bolts' },
  { id: 5, description: 'After ratcheting, click each bolt again to unscrew by hand', requiredTool: null, action: 'unscrew_bolts' },
  { id: 6, description: 'Click the valve cover to lift it off', requiredTool: null, action: 'remove_cover' },
]);

const oilChangeSteps = makeSteps([
  { id: 1, description: 'Select the Drain Pan and position it under the engine', requiredTool: 'drainPan', action: 'select_drain_pan' },
  { id: 2, description: 'Position the drain pan (click the Position button)', requiredTool: null, action: 'position_drain_pan' },
  { id: 3, description: 'Select the 13mm Socket for the drain plug', requiredTool: 'socket13', action: 'select_socket13' },
  { id: 4, description: 'Click the oil drain plug to remove it (oil will drain)', requiredTool: null, action: 'remove_drain_plug' },
  { id: 5, description: 'Wait for oil to drain completely (click drain plug again)', requiredTool: null, action: 'wait_drain' },
  { id: 6, description: 'Click the drain plug to reinstall and tighten', requiredTool: 'socket13', action: 'reinstall_drain_plug' },
  { id: 7, description: 'Select the Funnel to add new oil', requiredTool: 'funnel', action: 'select_funnel' },
  { id: 8, description: 'Click the oil fill opening to pour new oil', requiredTool: null, action: 'add_oil' },
]);

const oilFilterSteps = makeSteps([
  { id: 1, description: 'Position the Drain Pan under the oil filter', requiredTool: 'drainPan', action: 'select_drain_pan' },
  { id: 2, description: 'Click Position Drain Pan button', requiredTool: null, action: 'position_drain_pan' },
  { id: 3, description: 'Select the Oil Filter Wrench', requiredTool: 'filterWrench', action: 'select_filter_wrench' },
  { id: 4, description: 'Click the oil filter to loosen and remove it', requiredTool: null, action: 'remove_filter' },
  { id: 5, description: 'Apply oil to the new filter gasket (use Towel to clean area first)', requiredTool: 'towel', action: 'clean_filter_area' },
  { id: 6, description: 'Click the filter mount to install the new filter by hand', requiredTool: null, action: 'install_new_filter' },
]);

const fuelFilterSteps = makeSteps([
  { id: 1, description: 'Select the 21mm Socket', requiredTool: 'socket21', action: 'select_socket21' },
  { id: 2, description: 'Click the fuel filter housing bolt to loosen', requiredTool: null, action: 'loosen_fuel_bolt' },
  { id: 3, description: 'Unscrew and remove the fuel filter by hand', requiredTool: null, action: 'remove_fuel_filter' },
  { id: 4, description: 'Clean the area with a Towel', requiredTool: 'towel', action: 'clean_fuel_area' },
  { id: 5, description: 'Install the new fuel filter by hand and tighten', requiredTool: null, action: 'install_new_fuel_filter' },
]);

export const useEngineStore = create<EngineStore>((set, get) => ({
  isExploded: false,
  selectedTool: null,
  ratchetAttachments: [],
  hoveredPart: null,
  activeTask: 'none',
  procedureSteps: [],
  currentStepIndex: 0,
  valveCoverBolts: initialValveCoverBolts,
  valveCoverState: 'installed',
  oilDrainPlugState: 'tight',
  oilLevel: 'full',
  drainPanPositioned: false,
  oilFilterState: 'installed',
  fuelFilterState: 'installed',
  fuelFilterBoltState: 'tight',
  message: 'Welcome! Select a maintenance task from the panel to begin.',
  messageType: 'info',

  selectTool: (tool) => {
    if (!tool) {
      set({ selectedTool: null });
      return;
    }
    const { activeTask, currentStepIndex, procedureSteps } = get();
    const toolNames: Record<Tool, string> = {
      ratchet: 'Ratchet Wrench', socket8: '8mm Socket', socket10: '10mm Socket',
      socket13: '13mm Socket', socket15: '15mm Socket', socket21: '21mm Socket',
      extension: 'Extension Bar', drainPan: 'Drain Pan', filterWrench: 'Oil Filter Wrench',
      funnel: 'Funnel', screwdriver: 'Screwdriver', towel: 'Towel'
    };

    if (activeTask === 'none') {
      set({ selectedTool: tool, message: `Selected ${toolNames[tool]}`, messageType: 'info' });
      return;
    }

    const step = procedureSteps[currentStepIndex];
    if (step?.requiredTool && tool !== step.requiredTool) {
      set({ selectedTool: tool, message: `✗ Wrong tool! Step requires: ${step.requiredTool === 'ratchet' ? 'Ratchet Wrench' : toolNames[step.requiredTool]}`, messageType: 'error' });
      return;
    }

    // Validate correct tool for step
    if (step?.requiredTool && tool === step.requiredTool) {
      const msgs: Record<string, string> = {
        select_ratchet: '✓ Ratchet selected. Now attach the extension bar.',
        select_socket13: '✓ 13mm socket selected. Click the drain plug.',
        select_filter_wrench: '✓ Filter wrench selected. Click the oil filter.',
        select_socket21: '✓ 21mm socket selected. Click the fuel filter bolt.',
        select_funnel: '✓ Funnel selected. Click the oil fill opening.',
        select_drain_pan: '✓ Drain pan selected! Now position it.',
      };

      set({
        selectedTool: tool,
        message: `✓ ${toolNames[tool]} selected.${msgs[step.action] || ''}`,
        messageType: 'success',
        currentStepIndex: currentStepIndex + 1,
        procedureSteps: procedureSteps.map((s, i) => ({
          ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
        }))
      });
    } else {
      set({ selectedTool: tool, message: `Selected ${toolNames[tool]}`, messageType: 'info' });
    }
  },

  setRatchetAttachment: (attachment) => {
    const { activeTask, currentStepIndex, procedureSteps, ratchetAttachments } = get();
    if (activeTask !== 'valveCover') return;

    const step = procedureSteps[currentStepIndex];
    if (!step || attachment !== step.requiredTool) {
      set({ message: `✗ Wrong attachment for this step! Need ${step?.requiredTool === 'extension' ? 'Extension Bar' : step?.requiredTool === 'socket8' ? '8mm Socket' : 'correct tool'}.`, messageType: 'error' });
      return;
    }

    const newAttachments = [...ratchetAttachments, attachment];
    let message = '';
    let shouldAdvance = true;

    if (attachment === 'extension') {
      message = '✓ Extension attached to ratchet. Now attach the 8mm socket.';
    } else if (attachment === 'socket8') {
      if (!ratchetAttachments.includes('extension')) {
        set({ message: '✗ Attach the extension bar to the ratchet first!', messageType: 'error' });
        return;
      }
      message = '✓ Ratchet + Extension + 8mm Socket assembled! Now click each valve cover bolt to loosen them.';
    }

    if (shouldAdvance) {
      set({
        ratchetAttachments: newAttachments,
        selectedTool: 'ratchet',
        message,
        messageType: 'success',
        currentStepIndex: currentStepIndex + 1,
        procedureSteps: procedureSteps.map((s, i) => ({
          ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
        }))
      });
    }
  },

  clearRatchetAttachments: () => set({ ratchetAttachments: [] }),

  setActiveTask: (task) => {
    let steps: ProcedureStep[] = [];
    const taskMessages: Record<string, string> = {
      valveCover: '🔧 Valve Cover Removal - Follow the procedure steps carefully!',
      oilChange: '🛢️ Oil Change - Make sure to position the drain pan first!',
      oilFilter: '🔄 Oil Filter Change - Use the proper filter wrench!',
      fuelFilter: '⛽ Fuel Filter Change - Use the correct socket!',
    };

    switch (task) {
      case 'valveCover': steps = valCoverSteps; break;
      case 'oilChange': steps = oilChangeSteps; break;
      case 'oilFilter': steps = oilFilterSteps; break;
      case 'fuelFilter': steps = fuelFilterSteps; break;
    }

    set({
      activeTask: task,
      procedureSteps: steps,
      currentStepIndex: 0,
      selectedTool: null,
      ratchetAttachments: [],
      message: taskMessages[task] || '',
      messageType: 'info'
    });
  },

  advanceStep: () => {
    const { currentStepIndex, procedureSteps } = get();
    if (currentStepIndex + 1 >= procedureSteps.length) {
      set({
        activeTask: 'none', procedureSteps: [], currentStepIndex: 0,
        message: '✅ Task completed successfully! Great work!', messageType: 'success'
      });
      return;
    }
    set({
      currentStepIndex: currentStepIndex + 1,
      procedureSteps: procedureSteps.map((s, i) => ({
        ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
      })),
    });
  },

  clickBolt: (boltId) => {
    const { activeTask, procedureSteps, currentStepIndex, ratchetAttachments, valveCoverBolts } = get();
    if (activeTask !== 'valveCover') return;

    const step = procedureSteps[currentStepIndex];

    if (step?.action === 'loosen_bolts') {
      const hasFullRatchet = ratchetAttachments.includes('extension') && ratchetAttachments.includes('socket8');
      if (!hasFullRatchet) {
        set({ message: '✗ You need Ratchet + Extension + 8mm Socket assembled!', messageType: 'error' });
        return;
      }
      const updatedBolts: ValveCoverBolt[] = valveCoverBolts.map(b =>
        b.id === boltId && b.state === 'tight' ? { ...b, state: 'loose' as BoltState } : b
      );
      const allLoose = updatedBolts.every(b => b.state !== 'tight');
      set({ valveCoverBolts: updatedBolts });
      if (allLoose) {
        set({
          message: '✓ All bolts loosened! Now unscrew each bolt by hand (click again).',
          messageType: 'success', currentStepIndex: currentStepIndex + 1,
          procedureSteps: procedureSteps.map((s, i) => ({
            ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
          }))
        });
      } else {
        set({ message: `✓ Bolt ${boltId} loosened with ratchet. Continue...`, messageType: 'success' });
      }
    } else if (step?.action === 'unscrew_bolts') {
      const updatedBolts: ValveCoverBolt[] = valveCoverBolts.map(b =>
        b.id === boltId && b.state === 'loose' ? { ...b, state: 'removed' as BoltState } : b
      );
      const allRemoved = updatedBolts.every(b => b.state === 'removed');
      set({ valveCoverBolts: updatedBolts });
      if (allRemoved) {
        set({
          message: '✓ All bolts removed! Click the valve cover to lift it off.',
          messageType: 'success', currentStepIndex: currentStepIndex + 1,
          procedureSteps: procedureSteps.map((s, i) => ({
            ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
          }))
        });
      }
    }
  },

  clickPart: (partName) => {
    const { activeTask, procedureSteps, currentStepIndex, drainPanPositioned, oilLevel, selectedTool } = get();

    if (activeTask === 'valveCover' && partName === 'valveCover') {
      const step = procedureSteps[currentStepIndex];
      if (step?.action === 'remove_cover') {
        set({
          valveCoverState: 'removed', activeTask: 'none', procedureSteps: [],
          currentStepIndex: 0,
          message: '✅ Valve cover removed successfully! Cylinder head exposed.',
          messageType: 'success'
        });
      }
    }

    if (activeTask === 'oilChange') {
      const step = procedureSteps[currentStepIndex];

      if (partName === 'drainPlug') {
        if (step?.action === 'remove_drain_plug') {
          if (!drainPanPositioned) {
            set({ message: '✗ You must position the drain pan first!', messageType: 'error' });
            return;
          }
          if (selectedTool !== 'socket13') {
            set({ message: '✗ Select the 13mm socket first!', messageType: 'error' });
            return;
          }
          set({
            oilDrainPlugState: 'removed', oilLevel: 'draining',
            message: '⏳ Oil is draining...', messageType: 'warning',
            currentStepIndex: currentStepIndex + 1,
            procedureSteps: procedureSteps.map((s, i) => ({
              ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
            }))
          });
        } else if (step?.action === 'wait_drain' && oilLevel === 'draining') {
          set({
            oilLevel: 'drained',
            message: '✓ Oil drained. Reinstall the drain plug.',
            messageType: 'success', currentStepIndex: currentStepIndex + 1,
            procedureSteps: procedureSteps.map((s, i) => ({
              ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
            }))
          });
        } else if (step?.action === 'reinstall_drain_plug') {
          if (selectedTool !== 'socket13') {
            set({ message: '✗ Select the 13mm socket first!', messageType: 'error' });
            return;
          }
          set({
            oilDrainPlugState: 'tight',
            message: '✓ Drain plug reinstalled and tightened.', messageType: 'success',
            currentStepIndex: currentStepIndex + 1,
            procedureSteps: procedureSteps.map((s, i) => ({
              ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
            }))
          });
        }
      }

      if (partName === 'oilFill' && step?.action === 'add_oil') {
        if (selectedTool !== 'funnel') {
          set({ message: '✗ Select the Funnel first!', messageType: 'error' });
          return;
        }
        set({
          oilLevel: 'full', activeTask: 'none', procedureSteps: [],
          currentStepIndex: 0, drainPanPositioned: false,
          message: '✅ Oil change completed! Fresh 15W-40 oil added.',
          messageType: 'success'
        });
      }
    }

    if (activeTask === 'oilFilter') {
      const step = procedureSteps[currentStepIndex];

      if (partName === 'oilFilter' && step?.action === 'remove_filter') {
        if (!drainPanPositioned) {
          set({ message: '✗ Position the drain pan under the filter first!', messageType: 'error' });
          return;
        }
        if (selectedTool !== 'filterWrench') {
          set({ message: '✗ Select the Oil Filter Wrench first!', messageType: 'error' });
          return;
        }
        set({
          oilFilterState: 'removed',
          message: '✓ Old filter removed. Clean the area with a towel.',
          messageType: 'success', currentStepIndex: currentStepIndex + 1,
          procedureSteps: procedureSteps.map((s, i) => ({
            ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
          }))
        });
      }

      if (partName === 'filterMount' && step?.action === 'clean_filter_area') {
        if (selectedTool !== 'towel') {
          set({ message: '✗ Select the Towel first!', messageType: 'error' });
          return;
        }
        set({
          message: '✓ Filter area cleaned and gasket prepped with oil.',
          messageType: 'success', currentStepIndex: currentStepIndex + 1,
          procedureSteps: procedureSteps.map((s, i) => ({
            ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
          }))
        });
      }

      if (partName === 'filterMount' && step?.action === 'install_new_filter') {
        set({
          oilFilterState: 'installed_new', activeTask: 'none', procedureSteps: [],
          currentStepIndex: 0, drainPanPositioned: false,
          message: '✅ New oil filter installed! Hand-tightened ¾ turn.',
          messageType: 'success'
        });
      }
    }

    if (activeTask === 'fuelFilter') {
      const step = procedureSteps[currentStepIndex];

      if (partName === 'fuelFilterBolt' && step?.action === 'loosen_fuel_bolt') {
        if (selectedTool !== 'socket21') {
          set({ message: '✗ Select the 21mm socket first!', messageType: 'error' });
          return;
        }
        set({
          fuelFilterBoltState: 'loose',
          message: '✓ Fuel filter housing loosened. Now remove the filter.',
          messageType: 'success', currentStepIndex: currentStepIndex + 1,
          procedureSteps: procedureSteps.map((s, i) => ({
            ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
          }))
        });
      }

      if (partName === 'fuelFilter' && step?.action === 'remove_fuel_filter') {
        set({
          fuelFilterState: 'removed',
          message: '✓ Old fuel filter removed. Clean the area.',
          messageType: 'success', currentStepIndex: currentStepIndex + 1,
          procedureSteps: procedureSteps.map((s, i) => ({
            ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
          }))
        });
      }

      if (partName === 'fuelMount' && step?.action === 'clean_fuel_area') {
        if (selectedTool !== 'towel') {
          set({ message: '✗ Select the Towel first!', messageType: 'error' });
          return;
        }
        set({
          message: '✓ Fuel filter area cleaned.',
          messageType: 'success', currentStepIndex: currentStepIndex + 1,
          procedureSteps: procedureSteps.map((s, i) => ({
            ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
          }))
        });
      }

      if (partName === 'fuelMount' && step?.action === 'install_new_fuel_filter') {
        set({
          fuelFilterState: 'installed_new', fuelFilterBoltState: 'tight',
          activeTask: 'none', procedureSteps: [], currentStepIndex: 0,
          message: '✅ New fuel filter installed and tightened. Prime the fuel system.',
          messageType: 'success'
        });
      }
    }
  },

  positionDrainPan: () => {
    const { activeTask, procedureSteps, currentStepIndex, drainPanPositioned } = get();
    if (activeTask && (activeTask === 'oilChange' || activeTask === 'oilFilter')) {
      const step = procedureSteps[currentStepIndex];
      if (step?.action === 'position_drain_pan') {
        set({
          drainPanPositioned: true,
          message: '✓ Drain pan positioned under the engine.',
          messageType: 'success', currentStepIndex: currentStepIndex + 1,
          procedureSteps: procedureSteps.map((s, i) => ({
            ...s, completed: i === currentStepIndex, current: i === currentStepIndex + 1
          }))
        });
      } else {
        set({ drainPanPositioned: true, message: '✓ Drain pan positioned.', messageType: 'info' });
      }
    } else {
      set({
        drainPanPositioned: !drainPanPositioned,
        message: drainPanPositioned ? 'Drain pan removed.' : '✓ Drain pan positioned.',
        messageType: 'info'
      });
    }
  },

  showMessage: (message, type) => set({ message, messageType: type }),

  resetEngine: () => set({
    isExploded: false, selectedTool: null, ratchetAttachments: [],
    hoveredPart: null, activeTask: 'none', procedureSteps: [],
    currentStepIndex: 0,
    valveCoverBolts: initialValveCoverBolts,
    valveCoverState: 'installed',
    oilDrainPlugState: 'tight', oilLevel: 'full',
    drainPanPositioned: false, oilFilterState: 'installed',
    fuelFilterState: 'installed', fuelFilterBoltState: 'tight',
    message: 'Engine reset! Select a maintenance task to begin.', messageType: 'info'
  })
}));
