import { useState, useRef, useEffect, useCallback } from 'react';
import { ProfileCustomization } from './components/ProfileCustomization';
import { FriendsList } from './components/FriendsList';
import { SocialFeeds } from './components/SocialFeeds';
import { BioSection } from './components/BioSection';
import { StatsSection } from './components/StatsSection';

export interface ProfileSettings {
  backgroundColor: string;
  backgroundImage: string;
  backgroundGradient: string;
  useGradient: boolean;
  accentColor: string;
  textColor: string;
  bannerUrl: string;
  avatarUrl: string;
  bannerHeight: number;
  avatarSize: number;
  displayName: string;
  username: string;
  bio: string;
}

const defaultSettings: ProfileSettings = {
  backgroundColor: '#1a1a2e',
  backgroundImage: '',
  backgroundGradient: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
  useGradient: true,
  accentColor: '#e94560',
  textColor: '#ffffff',
  bannerUrl: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&h=400&fit=crop',
  avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop',
  bannerHeight: 280,
  avatarSize: 150,
  displayName: 'Alex Johnson',
  username: '@alexjohnson',
  bio: '✨ Digital creator & tech enthusiast | Building the future one line of code at a time | Coffee addict ☕',
};

export interface Friend {
  id: number;
  name: string;
  username: string;
  avatar: string;
  status: 'online' | 'offline' | 'away';
}

const sampleFriends: Friend[] = [
  { id: 1, name: 'Sarah Miller', username: '@sarahm', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop', status: 'online' },
  { id: 2, name: 'James Wilson', username: '@jamesw', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop', status: 'online' },
  { id: 3, name: 'Emily Chen', username: '@emilyc', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop', status: 'away' },
  { id: 4, name: 'Mike Brown', username: '@mikeb', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop', status: 'offline' },
  { id: 5, name: 'Lisa Park', username: '@lisap', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop', status: 'online' },
  { id: 6, name: 'David Kim', username: '@davidk', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop', status: 'offline' },
];

export interface SocialFeed {
  id: string;
  platform: 'twitter' | 'instagram' | 'youtube' | 'tiktok' | 'linkedin';
  icon: string;
  color: string;
  handle: string;
  followers: string;
  connected: boolean;
}

const defaultSocialFeeds: SocialFeed[] = [
  { id: '1', platform: 'twitter', icon: '𝕏', color: '#000000', handle: '@alexjohnson', followers: '12.5K', connected: true },
  { id: '2', platform: 'instagram', icon: '📷', color: '#E4405F', handle: '@alexcreates', followers: '8.2K', connected: true },
  { id: '3', platform: 'youtube', icon: '▶️', color: '#FF0000', handle: 'Alex Johnson', followers: '25.1K', connected: true },
  { id: '4', platform: 'tiktok', icon: '🎵', color: '#000000', handle: '@alexjofficial', followers: '45.3K', connected: false },
  { id: '5', platform: 'linkedin', icon: '💼', color: '#0A66C2', handle: 'Alex Johnson', followers: '5.8K', connected: true },
];

export interface ResizableElement {
  type: 'banner' | 'avatar';
  isResizing: boolean;
  startX: number;
  startY: number;
  startSize: number;
}

function App() {
  const [settings, setSettings] = useState<ProfileSettings>(defaultSettings);
  const [showCustomization, setShowCustomization] = useState(false);
  const [friends] = useState<Friend[]>(sampleFriends);
  const [socialFeeds, setSocialFeeds] = useState<SocialFeed[]>(defaultSocialFeeds);
  const [resizing, setResizing] = useState<ResizableElement | null>(null);
  const bannerRef = useRef<HTMLDivElement>(null);
  const avatarRef = useRef<HTMLDivElement>(null);

  const handleMouseDown = useCallback((e: React.MouseEvent, type: 'banner' | 'avatar') => {
    e.preventDefault();
    const currentSize = type === 'banner' ? settings.bannerHeight : settings.avatarSize;
    setResizing({
      type,
      isResizing: true,
      startX: e.clientX,
      startY: e.clientY,
      startSize: currentSize,
    });
  }, [settings.bannerHeight, settings.avatarSize]);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!resizing) return;
    
    const deltaY = e.clientY - resizing.startY;
    const delta = resizing.type === 'banner' ? deltaY : (deltaY + (e.clientX - resizing.startX)) / 2;
    const newSize = Math.max(
      resizing.type === 'banner' ? 150 : 80,
      Math.min(resizing.type === 'banner' ? 500 : 300, resizing.startSize + delta)
    );

    if (resizing.type === 'banner') {
      setSettings(prev => ({ ...prev, bannerHeight: newSize }));
    } else {
      setSettings(prev => ({ ...prev, avatarSize: newSize }));
    }
  }, [resizing]);

  const handleMouseUp = useCallback(() => {
    setResizing(null);
  }, []);

  useEffect(() => {
    if (resizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [resizing, handleMouseMove, handleMouseUp]);

  const getBackgroundStyle = () => {
    if (settings.backgroundImage) {
      return {
        backgroundImage: `url(${settings.backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
      };
    }
    if (settings.useGradient) {
      return { background: settings.backgroundGradient };
    }
    return { backgroundColor: settings.backgroundColor };
  };

  return (
    <div className="min-h-screen" style={getBackgroundStyle()}>
      {/* Customization Toggle Button */}
      <button
        onClick={() => setShowCustomization(!showCustomization)}
        className="fixed top-4 right-4 z-50 p-3 rounded-full shadow-lg transition-all duration-300 hover:scale-110"
        style={{ backgroundColor: settings.accentColor, color: settings.textColor }}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      </button>

      {/* Customization Panel */}
      {showCustomization && (
        <ProfileCustomization
          settings={settings}
          setSettings={setSettings}
          onClose={() => setShowCustomization(false)}
        />
      )}

      {/* Main Profile Content */}
      <div className="relative">
        {/* Banner */}
        <div
          ref={bannerRef}
          className="relative w-full overflow-hidden cursor-ns-resize group"
          style={{ height: settings.bannerHeight }}
        >
          <img
            src={settings.bannerUrl}
            alt="Profile Banner"
            className="w-full h-full object-cover"
            draggable={false}
          />
          <div 
            className="absolute inset-0 opacity-50"
            style={{ background: `linear-gradient(to bottom, transparent 0%, ${settings.accentColor}40 100%)` }}
          />
          
          {/* Banner Resize Handle */}
          <div
            className="absolute bottom-0 left-0 right-0 h-8 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-ns-resize"
            onMouseDown={(e) => handleMouseDown(e, 'banner')}
          >
            <div className="flex flex-col gap-1">
              <div className="w-8 h-1 bg-white/60 rounded-full" />
              <div className="w-8 h-1 bg-white/60 rounded-full" />
            </div>
            <span className="ml-3 text-white text-xs">Drag to resize</span>
          </div>
        </div>

        {/* Profile Info Section */}
        <div className="max-w-6xl mx-auto px-4 -mt-20 relative z-10">
          {/* Avatar */}
          <div className="flex flex-col md:flex-row gap-6 items-start">
            <div
              ref={avatarRef}
              className="relative group cursor-nwse-resize"
              style={{ width: settings.avatarSize, height: settings.avatarSize }}
              onMouseDown={(e) => handleMouseDown(e, 'avatar')}
            >
              <img
                src={settings.avatarUrl}
                alt="Profile Avatar"
                className="w-full h-full rounded-full object-cover border-4 shadow-xl"
                style={{ borderColor: settings.accentColor }}
                draggable={false}
              />
              <div 
                className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
                style={{ backgroundColor: `${settings.accentColor}80` }}
              >
                <span className="text-white text-xs font-medium text-center px-2">
                  Drag to resize
                </span>
              </div>
              {/* Online Status */}
              <div 
                className="absolute bottom-2 right-2 w-4 h-4 rounded-full border-2 border-white"
                style={{ backgroundColor: '#22c55e' }}
              />
            </div>

            {/* Name and Bio */}
            <div className="flex-1 pt-4 md:pt-24">
              <h1 
                className="text-3xl md:text-4xl font-bold drop-shadow-lg"
                style={{ color: settings.textColor }}
              >
                {settings.displayName}
              </h1>
              <p 
                className="text-lg opacity-80"
                style={{ color: settings.textColor }}
              >
                {settings.username}
              </p>
              <BioSection bio={settings.bio} textColor={settings.textColor} />
              <StatsSection accentColor={settings.accentColor} textColor={settings.textColor} />
            </div>
          </div>

          {/* Modules Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8 pb-12">
            {/* Social Feeds - Takes 2 columns */}
            <div className="lg:col-span-2">
              <SocialFeeds 
                feeds={socialFeeds} 
                setFeeds={setSocialFeeds}
                accentColor={settings.accentColor}
                textColor={settings.textColor}
              />
            </div>

            {/* Friends List */}
            <div className="lg:col-span-1">
              <FriendsList 
                friends={friends} 
                accentColor={settings.accentColor}
                textColor={settings.textColor}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
