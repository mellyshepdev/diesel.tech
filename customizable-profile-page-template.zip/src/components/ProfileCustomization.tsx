import { useState } from 'react';
import { ProfileSettings } from '../App';

interface ProfileCustomizationProps {
  settings: ProfileSettings;
  setSettings: React.Dispatch<React.SetStateAction<ProfileSettings>>;
  onClose: () => void;
}

const gradientPresets = [
  'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
  'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
  'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
  'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
  'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
  'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
  'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
  'linear-gradient(135deg, #2c3e50 0%, #4ca1af 100%)',
  'linear-gradient(135deg, #141e30 0%, #243b55 100%)',
  'linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%)',
  'linear-gradient(135deg, #ee0979 0%, #ff6a00 100%)',
];

const colorPresets = [
  '#1a1a2e', '#16213e', '#0f3460', '#e94560', '#533483', '#2c3e50',
  '#1abc9c', '#3498db', '#9b59b6', '#e74c3c', '#f39c12', '#27ae60',
];

const accentPresets = [
  '#e94560', '#f39c12', '#3498db', '#2ecc71', '#9b59b6', '#1abc9c',
  '#e74c3c', '#f1c40f', '#16a085', '#8e44ad', '#2980b9', '#c0392b',
];

export function ProfileCustomization({ settings, setSettings, onClose }: ProfileCustomizationProps) {
  const [activeTab, setActiveTab] = useState<'background' | 'images' | 'profile'>('background');

  const updateSetting = <K extends keyof ProfileSettings>(key: K, value: ProfileSettings[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div 
        className="w-full max-w-2xl max-h-[90vh] overflow-hidden rounded-2xl shadow-2xl"
        style={{ backgroundColor: '#1e1e2e', color: '#fff' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <h2 className="text-xl font-bold">Customize Your Profile</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/10">
          {[
            { id: 'background', label: '🎨 Background' },
            { id: 'images', label: '🖼️ Images' },
            { id: 'profile', label: '👤 Profile' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id ? 'border-b-2' : 'opacity-60 hover:opacity-100'
              }`}
              style={{ 
                borderColor: activeTab === tab.id ? settings.accentColor : 'transparent',
                color: activeTab === tab.id ? settings.accentColor : undefined
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto max-h-[60vh]">
          {activeTab === 'background' && (
            <div className="space-y-6">
              {/* Background Type Toggle */}
              <div>
                <label className="block text-sm font-medium mb-2">Background Type</label>
                <div className="flex gap-2">
                  <button
                    onClick={() => updateSetting('useGradient', true)}
                    className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
                      settings.useGradient ? 'ring-2' : 'bg-white/10'
                    }`}
                    style={{ 
                      backgroundColor: settings.useGradient ? settings.accentColor : undefined,
                      '--tw-ring-color': settings.accentColor
                    } as React.CSSProperties}
                  >
                    Gradient
                  </button>
                  <button
                    onClick={() => updateSetting('useGradient', false)}
                    className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
                      !settings.useGradient ? 'ring-2' : 'bg-white/10'
                    }`}
                    style={{ 
                      backgroundColor: !settings.useGradient ? settings.accentColor : undefined,
                    }}
                  >
                    Solid Color
                  </button>
                </div>
              </div>

              {/* Gradient Presets */}
              {settings.useGradient && (
                <div>
                  <label className="block text-sm font-medium mb-2">Gradient Presets</label>
                  <div className="grid grid-cols-4 gap-2">
                    {gradientPresets.map((gradient, i) => (
                      <button
                        key={i}
                        onClick={() => updateSetting('backgroundGradient', gradient)}
                        className={`h-12 rounded-lg transition-transform hover:scale-105 ${
                          settings.backgroundGradient === gradient ? 'ring-2 ring-white' : ''
                        }`}
                        style={{ background: gradient }}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Solid Color Options */}
              {!settings.useGradient && (
                <div>
                  <label className="block text-sm font-medium mb-2">Background Color</label>
                  <div className="grid grid-cols-6 gap-2 mb-3">
                    {colorPresets.map((color, i) => (
                      <button
                        key={i}
                        onClick={() => updateSetting('backgroundColor', color)}
                        className={`h-10 rounded-lg transition-transform hover:scale-105 ${
                          settings.backgroundColor === color ? 'ring-2 ring-white' : ''
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                  <input
                    type="color"
                    value={settings.backgroundColor}
                    onChange={(e) => updateSetting('backgroundColor', e.target.value)}
                    className="w-full h-10 rounded-lg cursor-pointer"
                  />
                </div>
              )}

              {/* Custom Background Image */}
              <div>
                <label className="block text-sm font-medium mb-2">Custom Background Image URL</label>
                <input
                  type="text"
                  value={settings.backgroundImage}
                  onChange={(e) => updateSetting('backgroundImage', e.target.value)}
                  placeholder="Enter image URL or leave empty for gradient/color"
                  className="w-full px-4 py-2 rounded-lg bg-white/10 border border-white/20 focus:border-white/40 focus:outline-none"
                />
                {settings.backgroundImage && (
                  <button
                    onClick={() => updateSetting('backgroundImage', '')}
                    className="mt-2 text-sm text-red-400 hover:text-red-300"
                  >
                    Remove background image
                  </button>
                )}
              </div>

              {/* Accent Color */}
              <div>
                <label className="block text-sm font-medium mb-2">Accent Color</label>
                <div className="grid grid-cols-6 gap-2 mb-3">
                  {accentPresets.map((color, i) => (
                    <button
                      key={i}
                      onClick={() => updateSetting('accentColor', color)}
                      className={`h-10 rounded-lg transition-transform hover:scale-105 ${
                        settings.accentColor === color ? 'ring-2 ring-white' : ''
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
                <input
                  type="color"
                  value={settings.accentColor}
                  onChange={(e) => updateSetting('accentColor', e.target.value)}
                  className="w-full h-10 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          )}

          {activeTab === 'images' && (
            <div className="space-y-6">
              {/* Banner Image */}
              <div>
                <label className="block text-sm font-medium mb-2">Banner Image URL</label>
                <input
                  type="text"
                  value={settings.bannerUrl}
                  onChange={(e) => updateSetting('bannerUrl', e.target.value)}
                  placeholder="Enter banner image URL"
                  className="w-full px-4 py-2 rounded-lg bg-white/10 border border-white/20 focus:border-white/40 focus:outline-none"
                />
                {settings.bannerUrl && (
                  <div className="mt-3 overflow-hidden rounded-lg">
                    <img 
                      src={settings.bannerUrl} 
                      alt="Banner preview" 
                      className="w-full h-32 object-cover"
                    />
                  </div>
                )}
              </div>

              {/* Avatar Image */}
              <div>
                <label className="block text-sm font-medium mb-2">Profile Picture URL</label>
                <input
                  type="text"
                  value={settings.avatarUrl}
                  onChange={(e) => updateSetting('avatarUrl', e.target.value)}
                  placeholder="Enter avatar image URL"
                  className="w-full px-4 py-2 rounded-lg bg-white/10 border border-white/20 focus:border-white/40 focus:outline-none"
                />
                {settings.avatarUrl && (
                  <div className="mt-3 flex justify-center">
                    <img 
                      src={settings.avatarUrl} 
                      alt="Avatar preview" 
                      className="w-24 h-24 rounded-full object-cover border-4"
                      style={{ borderColor: settings.accentColor }}
                    />
                  </div>
                )}
              </div>

              {/* Size Controls */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Banner Height: {settings.bannerHeight}px
                </label>
                <input
                  type="range"
                  min={150}
                  max={500}
                  value={settings.bannerHeight}
                  onChange={(e) => updateSetting('bannerHeight', Number(e.target.value))}
                  className="w-full"
                  style={{ accentColor: settings.accentColor }}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Avatar Size: {settings.avatarSize}px
                </label>
                <input
                  type="range"
                  min={80}
                  max={300}
                  value={settings.avatarSize}
                  onChange={(e) => updateSetting('avatarSize', Number(e.target.value))}
                  className="w-full"
                  style={{ accentColor: settings.accentColor }}
                />
              </div>
            </div>
          )}

          {activeTab === 'profile' && (
            <div className="space-y-6">
              {/* Display Name */}
              <div>
                <label className="block text-sm font-medium mb-2">Display Name</label>
                <input
                  type="text"
                  value={settings.displayName}
                  onChange={(e) => updateSetting('displayName', e.target.value)}
                  placeholder="Your display name"
                  className="w-full px-4 py-2 rounded-lg bg-white/10 border border-white/20 focus:border-white/40 focus:outline-none"
                />
              </div>

              {/* Username */}
              <div>
                <label className="block text-sm font-medium mb-2">Username</label>
                <input
                  type="text"
                  value={settings.username}
                  onChange={(e) => updateSetting('username', e.target.value)}
                  placeholder="@username"
                  className="w-full px-4 py-2 rounded-lg bg-white/10 border border-white/20 focus:border-white/40 focus:outline-none"
                />
              </div>

              {/* Bio */}
              <div>
                <label className="block text-sm font-medium mb-2">Bio</label>
                <textarea
                  value={settings.bio}
                  onChange={(e) => updateSetting('bio', e.target.value)}
                  placeholder="Tell us about yourself..."
                  rows={4}
                  className="w-full px-4 py-2 rounded-lg bg-white/10 border border-white/20 focus:border-white/40 focus:outline-none resize-none"
                />
              </div>

              {/* Text Color */}
              <div>
                <label className="block text-sm font-medium mb-2">Text Color</label>
                <div className="flex gap-2">
                  {['#ffffff', '#000000', '#f0f0f0', '#333333'].map((color) => (
                    <button
                      key={color}
                      onClick={() => updateSetting('textColor', color)}
                      className={`w-10 h-10 rounded-lg border-2 transition-transform hover:scale-105 ${
                        settings.textColor === color ? 'border-blue-500' : 'border-white/20'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                  <input
                    type="color"
                    value={settings.textColor}
                    onChange={(e) => updateSetting('textColor', e.target.value)}
                    className="w-10 h-10 rounded-lg cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-lg font-medium transition-transform hover:scale-[1.02]"
            style={{ backgroundColor: settings.accentColor }}
          >
            Save & Close
          </button>
        </div>
      </div>
    </div>
  );
}
