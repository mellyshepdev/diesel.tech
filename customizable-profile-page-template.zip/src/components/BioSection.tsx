interface BioSectionProps {
  bio: string;
  textColor: string;
}

export function BioSection({ bio, textColor }: BioSectionProps) {
  return (
    <p 
      className="mt-3 text-sm leading-relaxed max-w-xl"
      style={{ color: textColor, opacity: 0.9 }}
    >
      {bio}
    </p>
  );
}
