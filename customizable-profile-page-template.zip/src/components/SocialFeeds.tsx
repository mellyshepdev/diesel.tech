import { useState } from 'react';
import { SocialFeed } from '../App';

interface SocialFeedsProps {
  feeds: SocialFeed[];
  setFeeds: React.Dispatch<React.SetStateAction<SocialFeed[]>>;
  accentColor: string;
  textColor: string;
}

export function SocialFeeds({ feeds, setFeeds, accentColor, textColor }: SocialFeedsProps) {
  const [selectedFeed, setSelectedFeed] = useState<string | null>(null);

  const toggleConnection = (id: string) => {
    setFeeds(prev => 
      prev.map(feed => 
        feed.id === id ? { ...feed, connected: !feed.connected } : feed
      )
    );
  };

  const connectedFeeds = feeds.filter(f => f.connected);
  const allFeeds = feeds;

  return (
    <div 
      className="rounded-2xl p-5 backdrop-blur-md"
      style={{ 
        backgroundColor: 'rgba(0, 0, 0, 0.4)',
        border: `1px solid ${accentColor}30`
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 
          className="text-lg font-bold flex items-center gap-2"
          style={{ color: textColor }}
        >
          <span 
            className="w-8 h-8 rounded-full flex items-center justify-center text-sm"
            style={{ backgroundColor: accentColor }}
          >
            🌐
          </span>
          Connected Socials
        </h3>
        <span 
          className="text-sm px-2 py-1 rounded-full"
          style={{ backgroundColor: `${accentColor}30`, color: accentColor }}
        >
          {connectedFeeds.length} connected
        </span>
      </div>

      {/* Connected Feeds Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
        {allFeeds.map((feed) => (
          <div
            key={feed.id}
            className={`relative p-4 rounded-xl cursor-pointer transition-all ${
              selectedFeed === feed.id ? 'ring-2' : 'hover:scale-[1.02]'
            }`}
            style={{ 
              backgroundColor: feed.connected ? `${feed.color}15` : 'rgba(255,255,255,0.05)',
              border: `1px solid ${feed.connected ? feed.color : 'rgba(255,255,255,0.1)'}`,
              opacity: feed.connected ? 1 : 0.6,
              '--tw-ring-color': accentColor
            } as React.CSSProperties}
            onClick={() => setSelectedFeed(selectedFeed === feed.id ? null : feed.id)}
          >
            <div className="flex items-center gap-3">
              <div 
                className="w-12 h-12 rounded-xl flex items-center justify-center text-xl"
                style={{ backgroundColor: feed.color }}
              >
                {feed.icon}
              </div>
              <div className="flex-1 min-w-0">
                <p 
                  className="font-medium capitalize text-sm"
                  style={{ color: textColor }}
                >
                  {feed.platform}
                </p>
                <p 
                  className="text-xs opacity-60 truncate"
                  style={{ color: textColor }}
                >
                  {feed.handle}
                </p>
              </div>
              <div className="text-right">
                <p 
                  className="font-bold text-sm"
                  style={{ color: feed.connected ? feed.color : textColor }}
                >
                  {feed.followers}
                </p>
                <p 
                  className="text-xs opacity-50"
                  style={{ color: textColor }}
                >
                  followers
                </p>
              </div>
            </div>

            {/* Connection Toggle */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleConnection(feed.id);
              }}
              className={`absolute top-2 right-2 w-8 h-5 rounded-full transition-colors ${
                feed.connected ? '' : 'bg-white/20'
              }`}
              style={{ backgroundColor: feed.connected ? feed.color : undefined }}
            >
              <div 
                className={`w-4 h-4 rounded-full bg-white shadow-md transform transition-transform ${
                  feed.connected ? 'translate-x-3.5' : 'translate-x-0.5'
                }`}
              />
            </button>

            {/* Expandable Feed Preview */}
            {selectedFeed === feed.id && feed.connected && (
              <div className="mt-4 pt-4 border-t border-white/10">
                <div 
                  className="p-3 rounded-lg text-xs"
                  style={{ backgroundColor: 'rgba(0,0,0,0.3)', color: textColor }}
                >
                  <p className="opacity-60 mb-2">Recent {feed.platform} activity:</p>
                  <div className="space-y-2">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-start gap-2">
                        <div 
                          className="w-2 h-2 rounded-full mt-1.5"
                          style={{ backgroundColor: feed.color }}
                        />
                        <p className="opacity-80">
                          {feed.platform === 'twitter' && "Just shipped a new feature! 🚀 Check it out..."}
                          {feed.platform === 'instagram' && "New photo from my latest adventure 📸"}
                          {feed.platform === 'youtube' && "NEW VIDEO: Building something amazing..."}
                          {feed.platform === 'tiktok' && "Trending now! Thanks for 45K! 🎉"}
                          {feed.platform === 'linkedin' && "Excited to announce my new role at..."}
                        </p>
                      </div>
                    ))}
                  </div>
                  <button
                    className="w-full mt-3 py-2 rounded-lg text-xs font-medium transition-colors"
                    style={{ 
                      backgroundColor: `${feed.color}30`,
                      color: textColor 
                    }}
                  >
                    View Full Feed
                  </button>
                </div>
              </div>
            )}

            {!feed.connected && selectedFeed === feed.id && (
              <div className="mt-4 pt-4 border-t border-white/10">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleConnection(feed.id);
                  }}
                  className="w-full py-2 rounded-lg text-sm font-medium transition-colors"
                  style={{ 
                    backgroundColor: feed.color,
                    color: '#fff'
                  }}
                >
                  Connect {feed.platform}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Add More Platforms */}
      <button
        className="w-full py-3 rounded-xl text-sm font-medium transition-all hover:scale-[1.02] border-2 border-dashed flex items-center justify-center gap-2"
        style={{ 
          borderColor: `${textColor}30`,
          color: textColor,
          opacity: 0.7
        }}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
        Add Another Platform
      </button>
    </div>
  );
}
