import { useState } from 'react';

interface StatsSectionProps {
  accentColor: string;
  textColor: string;
}

interface Stat {
  label: string;
  value: string;
  icon: string;
}

const stats: Stat[] = [
  { label: 'Followers', value: '12.5K', icon: '👥' },
  { label: 'Following', value: '847', icon: '➕' },
  { label: 'Posts', value: '1,234', icon: '📝' },
  { label: 'Likes', value: '89.2K', icon: '❤️' },
];

export function StatsSection({ accentColor, textColor }: StatsSectionProps) {
  const [hoveredStat, setHoveredStat] = useState<string | null>(null);

  return (
    <div className="flex flex-wrap gap-4 mt-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="flex items-center gap-2 px-4 py-2 rounded-xl cursor-pointer transition-all duration-300"
          style={{ 
            backgroundColor: hoveredStat === stat.label ? `${accentColor}30` : 'rgba(255,255,255,0.1)',
            transform: hoveredStat === stat.label ? 'scale(1.05)' : 'scale(1)'
          }}
          onMouseEnter={() => setHoveredStat(stat.label)}
          onMouseLeave={() => setHoveredStat(null)}
        >
          <span className="text-lg">{stat.icon}</span>
          <div>
            <p 
              className="font-bold text-sm"
              style={{ color: textColor }}
            >
              {stat.value}
            </p>
            <p 
              className="text-xs opacity-60"
              style={{ color: textColor }}
            >
              {stat.label}
            </p>
          </div>
        </div>
      ))}
      
      {/* Action Buttons */}
      <div className="flex gap-2 ml-auto">
        <button
          className="px-5 py-2 rounded-xl font-medium text-sm transition-all hover:scale-105"
          style={{ 
            backgroundColor: accentColor,
            color: textColor
          }}
        >
          Follow
        </button>
        <button
          className="px-5 py-2 rounded-xl font-medium text-sm transition-all hover:scale-105"
          style={{ 
            backgroundColor: 'rgba(255,255,255,0.1)',
            color: textColor,
            border: `1px solid ${textColor}30`
          }}
        >
          Message
        </button>
      </div>
    </div>
  );
}
