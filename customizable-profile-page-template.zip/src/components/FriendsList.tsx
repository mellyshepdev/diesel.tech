import { Friend } from '../App';

interface FriendsListProps {
  friends: Friend[];
  accentColor: string;
  textColor: string;
}

export function FriendsList({ friends, accentColor, textColor }: FriendsListProps) {
  const onlineFriends = friends.filter(f => f.status !== 'offline');
  const allFriends = friends;

  return (
    <div 
      className="rounded-2xl p-5 backdrop-blur-md"
      style={{ 
        backgroundColor: 'rgba(0, 0, 0, 0.4)',
        border: `1px solid ${accentColor}30`
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 
          className="text-lg font-bold flex items-center gap-2"
          style={{ color: textColor }}
        >
          <span 
            className="w-8 h-8 rounded-full flex items-center justify-center text-sm"
            style={{ backgroundColor: accentColor }}
          >
            👥
          </span>
          Friends
        </h3>
        <span 
          className="text-sm px-2 py-1 rounded-full"
          style={{ backgroundColor: `${accentColor}30`, color: accentColor }}
        >
          {onlineFriends.length} online
        </span>
      </div>

      <div className="space-y-2">
        {allFriends.map((friend) => (
          <div
            key={friend.id}
            className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition-colors cursor-pointer group"
          >
            <div className="relative">
              <img
                src={friend.avatar}
                alt={friend.name}
                className="w-11 h-11 rounded-full object-cover"
              />
              <div
                className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#1e1e2e]"
                style={{ 
                  backgroundColor: 
                    friend.status === 'online' ? '#22c55e' : 
                    friend.status === 'away' ? '#f59e0b' : '#6b7280'
                }}
              />
            </div>
            <div className="flex-1 min-w-0">
              <p 
                className="font-medium truncate text-sm"
                style={{ color: textColor }}
              >
                {friend.name}
              </p>
              <p 
                className="text-xs truncate opacity-60"
                style={{ color: textColor }}
              >
                {friend.username}
              </p>
            </div>
            <button
              className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-full"
              style={{ backgroundColor: `${accentColor}30` }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" style={{ color: accentColor }}>
                <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
              </svg>
            </button>
          </div>
        ))}
      </div>

      <button
        className="w-full mt-4 py-2.5 rounded-xl text-sm font-medium transition-all hover:scale-[1.02]"
        style={{ 
          backgroundColor: `${accentColor}20`,
          color: accentColor,
          border: `1px solid ${accentColor}40`
        }}
      >
        View All Friends ({allFriends.length})
      </button>
    </div>
  );
}
